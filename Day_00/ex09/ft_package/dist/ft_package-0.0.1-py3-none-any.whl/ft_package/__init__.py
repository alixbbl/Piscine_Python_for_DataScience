from ft_package import count_in_list

#ici on importe ce qui a ete fait
